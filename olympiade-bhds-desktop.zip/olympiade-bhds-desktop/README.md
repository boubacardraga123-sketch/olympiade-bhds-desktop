# 🏆 Olympiade des Cerveaux Guinée — Desktop

> Application desktop PC pour la compétition scolaire guinéenne  
> **Collection BHDS © 2026**

---

## 📥 Téléchargement rapide

Rendez-vous dans l'onglet **[Releases](../../releases)** pour télécharger l'installateur.

| Plateforme | Format |
|---|---|
| 🪟 Windows | `.exe` (installateur) |
| 🐧 Linux | `.AppImage` |

---

## 🛠️ Développement local

### Prérequis
- [Node.js](https://nodejs.org) v18 ou supérieur
- [Git](https://git-scm.com)

### Installation

```bash
# 1. Cloner le dépôt
git clone https://github.com/TON_USERNAME/olympiade-bhds-desktop.git
cd olympiade-bhds-desktop

# 2. Installer les dépendances
npm install

# 3. Lancer l'app
npm start
```

---

## 📦 Compiler l'application

```bash
# Windows (.exe)
npm run build:win

# Linux (.AppImage)
npm run build:linux

# Les deux
npm run build:all
```

Les fichiers compilés apparaissent dans le dossier `dist/`.

---

## 🚀 Publier une nouvelle version

```bash
# 1. Modifier la version dans package.json (ex: 1.1.0)

# 2. Commit + tag
git add .
git commit -m "Release v1.1.0"
git tag v1.1.0
git push origin main --tags
```

➡️ GitHub Actions compile automatiquement le `.exe` et publie une Release.

---

## 📁 Structure du projet

```
olympiade-bhds-desktop/
├── main.js              ← Processus principal Electron
├── preload.js           ← Pont sécurisé Main ↔ Renderer
├── package.json         ← Config Node.js & electron-builder
├── .gitignore
├── assets/
│   └── icon.png         ← Icône de l'app
├── src/
│   └── index.html       ← L'application (OlymBHDS)
└── .github/
    └── workflows/
        └── build.yml    ← Build automatique GitHub Actions
```

---

## ⌨️ Raccourcis clavier

| Touche | Action |
|---|---|
| `F5` | Recharger l'app |
| `F11` | Plein écran |
| `F12` | Outils développeur |
| `Ctrl+E` | Exporter les données |
| `Ctrl+I` | Importer des données |
| `Ctrl+=` / `Ctrl+-` | Zoom + / - |
| `Alt+F4` | Quitter |

---

**Collection BHDS** — Pour l'éducation guinéenne 🇬🇳
