#!/bin/bash
# ═══════════════════════════════════════════════════════
#  SETUP RAPIDE — Olympiade BHDS Desktop
#  Exécuter : bash setup.sh
# ═══════════════════════════════════════════════════════

echo ""
echo "🏆 Olympiade des Cerveaux Guinée — Setup Desktop"
echo "Collection BHDS © 2026"
echo "══════════════════════════════════════════════════"
echo ""

# 1. Vérifier Node.js
if ! command -v node &> /dev/null; then
  echo "❌ Node.js n'est pas installé."
  echo "   Télécharge-le sur : https://nodejs.org"
  exit 1
fi
echo "✅ Node.js $(node -v) détecté"

# 2. Vérifier Git
if ! command -v git &> /dev/null; then
  echo "❌ Git n'est pas installé."
  echo "   Télécharge-le sur : https://git-scm.com"
  exit 1
fi
echo "✅ Git $(git --version | cut -d' ' -f3) détecté"

# 3. Installer les dépendances
echo ""
echo "📦 Installation des dépendances..."
npm install

if [ $? -ne 0 ]; then
  echo "❌ Erreur lors de npm install"
  exit 1
fi
echo "✅ Dépendances installées"

# 4. Lancer l'app
echo ""
echo "🚀 Lancement de l'application..."
echo ""
npm start
