// ═══════════════════════════════════════════════════════
//  PRELOAD.JS — Pont sécurisé Main ↔ Renderer
//  Collection BHDS © 2026
// ═══════════════════════════════════════════════════════

const { contextBridge, ipcRenderer } = require('electron');

// Expose une API sécurisée dans window.electronAPI
contextBridge.exposeInMainWorld('electronAPI', {

  // ── Infos plateforme ──
  platform: process.platform,
  isElectron: true,

  // ── Sauvegarde fichier (dialogue natif) ──
  saveFile: (options) => ipcRenderer.invoke('save-file', options),

  // ── Ouverture fichier (dialogue natif) ──
  openFile: (options) => ipcRenderer.invoke('open-file', options),

  // ── Écouter les commandes du menu ──
  onMenuExport:    (cb) => ipcRenderer.on('menu-export',     () => cb()),
  onMenuImport:    (cb) => ipcRenderer.on('menu-import',     () => cb()),
  onMenuClearData: (cb) => ipcRenderer.on('menu-clear-data', () => cb()),
});
