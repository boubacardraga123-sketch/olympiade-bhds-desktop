// ═══════════════════════════════════════════════════════
//  OLYMPIADE DES CERVEAUX GUINÉE — Electron Main Process
//  Collection BHDS © 2026
// ═══════════════════════════════════════════════════════

const { app, BrowserWindow, Menu, shell, ipcMain, dialog } = require('electron');
const path = require('path');
const fs   = require('fs');

// ── Empêcher plusieurs instances simultanées ──
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) { app.quit(); }

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width:  1280,
    height: 820,
    minWidth:  900,
    minHeight: 600,
    title: 'Olympiade des Cerveaux Guinée — BHDS',
    icon: path.join(__dirname, 'assets', 'icon.png'),

    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      // Autoriser les requêtes Firebase (externe)
      webSecurity: true,
    },

    // Apparence de la fenêtre
    backgroundColor: '#0D1B2E',
    show: false, // on attend 'ready-to-show'
  });

  // Charger l'app
  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));

  // Afficher proprement quand prêt
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  // Ouvrir les liens externes dans le navigateur système (pas dans Electron)
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  // Menu personnalisé
  buildMenu();
}

// ── Menu application ──
function buildMenu() {
  const template = [
    {
      label: '📋 Application',
      submenu: [
        {
          label: '🔄 Recharger',
          accelerator: 'F5',
          click: () => mainWindow.webContents.reload()
        },
        {
          label: '🖥️ Plein écran',
          accelerator: 'F11',
          click: () => mainWindow.setFullScreen(!mainWindow.isFullScreen())
        },
        { type: 'separator' },
        {
          label: '❌ Quitter',
          accelerator: process.platform === 'darwin' ? 'Cmd+Q' : 'Alt+F4',
          click: () => app.quit()
        }
      ]
    },
    {
      label: '📁 Données',
      submenu: [
        {
          label: '📤 Exporter les données (JSON)',
          accelerator: 'Ctrl+E',
          click: () => mainWindow.webContents.send('menu-export')
        },
        {
          label: '📥 Importer des données (JSON)',
          accelerator: 'Ctrl+I',
          click: () => mainWindow.webContents.send('menu-import')
        },
        { type: 'separator' },
        {
          label: '🗑️ Effacer les données locales',
          click: async () => {
            const { response } = await dialog.showMessageBox(mainWindow, {
              type: 'warning',
              title: 'Confirmation',
              message: 'Effacer toutes les données locales ?',
              detail: 'Cette action est irréversible.',
              buttons: ['Annuler', 'Effacer'],
              defaultId: 0,
              cancelId: 0
            });
            if (response === 1) {
              mainWindow.webContents.send('menu-clear-data');
            }
          }
        }
      ]
    },
    {
      label: '🛠️ Développement',
      submenu: [
        {
          label: '🔍 Outils développeur',
          accelerator: 'F12',
          click: () => mainWindow.webContents.toggleDevTools()
        },
        {
          label: '📐 Zoom +',
          accelerator: 'Ctrl+=',
          click: () => {
            const z = mainWindow.webContents.getZoomFactor();
            mainWindow.webContents.setZoomFactor(Math.min(z + 0.1, 2.0));
          }
        },
        {
          label: '📐 Zoom -',
          accelerator: 'Ctrl+-',
          click: () => {
            const z = mainWindow.webContents.getZoomFactor();
            mainWindow.webContents.setZoomFactor(Math.max(z - 0.1, 0.5));
          }
        },
        {
          label: '📐 Zoom normal',
          accelerator: 'Ctrl+0',
          click: () => mainWindow.webContents.setZoomFactor(1.0)
        }
      ]
    },
    {
      label: 'ℹ️ À propos',
      submenu: [
        {
          label: '📖 À propos de l\'app',
          click: async () => {
            await dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'Olympiade des Cerveaux Guinée',
              message: 'Olympiade des Cerveaux Guinée',
              detail:
                'Collection BHDS © 2026\n' +
                'Application desktop pour les élèves guinéens.\n\n' +
                'Version : ' + app.getVersion() + '\n' +
                'Electron : ' + process.versions.electron + '\n' +
                'Node.js  : ' + process.versions.node,
              buttons: ['OK']
            });
          }
        },
        {
          label: '🌐 Site BHDS',
          click: () => shell.openExternal('https://github.com')
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// ── IPC : sauvegarde fichier depuis le renderer ──
ipcMain.handle('save-file', async (event, { defaultName, content, filters }) => {
  const { filePath, canceled } = await dialog.showSaveDialog(mainWindow, {
    title: 'Enregistrer le fichier',
    defaultPath: defaultName || 'export.json',
    filters: filters || [{ name: 'JSON', extensions: ['json'] }]
  });
  if (canceled || !filePath) return { ok: false };
  try {
    fs.writeFileSync(filePath, content, 'utf-8');
    return { ok: true, filePath };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// ── IPC : lire fichier depuis le renderer ──
ipcMain.handle('open-file', async (event, { filters }) => {
  const { filePaths, canceled } = await dialog.showOpenDialog(mainWindow, {
    title: 'Ouvrir un fichier',
    filters: filters || [{ name: 'JSON', extensions: ['json'] }],
    properties: ['openFile']
  });
  if (canceled || !filePaths.length) return { ok: false };
  try {
    const content = fs.readFileSync(filePaths[0], 'utf-8');
    return { ok: true, content, filePath: filePaths[0] };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// ── Cycle de vie de l'app ──
app.whenReady().then(createWindow);

app.on('second-instance', () => {
  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.focus();
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
